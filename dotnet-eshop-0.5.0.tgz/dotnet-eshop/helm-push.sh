helm package .
cp dotnet-eshop-*.tgz ~/work/my-projects/helm-charts/
pushd ~/work/my-projects/helm-charts
./refresh-index.sh
# git add dotnet-eshop-*.tgz index.yaml
# git commit -m "add dotnet-eshop $(ls dotnet-eshop-*.tgz | head -1 | sed 's/dotnet-eshop-//;s/\.tgz//')"
# git push
# popd
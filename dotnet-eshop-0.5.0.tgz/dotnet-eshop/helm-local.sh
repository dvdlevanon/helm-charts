#!/bin/bash

helm -n dotnet-eshop upgrade --install dotnet-eshop -f values.enable.yaml .
# helm -n dotnet-eshop upgrade --install dotnet-eshop -f values.disable.yaml .
# helm -n dotnet-eshop uninstall dotnet-eshop
